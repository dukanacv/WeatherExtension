
define([
    'uiComponent',
    'ko',
    'mage/storage',
    'jquery',
    'mage/translate',
    'mage/url',
    'moment',
    'mage/mage',
    'mage/calendar',

], function (Component, ko, storage, $, $t,url,moment) {
    'use strict'

    return Component.extend({
        defaults: {
            template:'Mageclass_WeatherProject/weather-form',
            city: ko.observable(''),
            temp: ko.observable(''),
            message: ko.observable(''),
            dateFrom: ko.observable(''),
            dateTo: ko.observable(''),
            errorMessage: ko.observable(''),
            weatherRecordsHistory: ko.observable({})
        },
        initialize(){
            this._super()
        },
        handlePostWeatherRecord(){
            let self = this;

            this.errorMessage('');

            let date = moment().format('YYYY-MM-DD');

            let restUrl = url.build('rest/V1/mageclass_weatherproject/saveByCityAndDate');

            $.ajax({
                url: restUrl,
                type: "POST",
                contentType: 'application/json',
                dataType: 'json',
                global: true,
                cache: false,
                processData: false,
                data: JSON.stringify(
                    {
                        "weather": {
                            "city": this.city(),
                            "temp": Math.round(this.temp()-273.15),
                            "date": date
                        }
                    }
                ),
                success: function(response){
                },
                error: function(error){
                    self.errorMessage('There was a problem with REST routing.');
                }
            })
        },
        handleSubmit(){
            this.message('');
            this.errorMessage('');
            let self = this;

            let jsonObjectOfWeatherConfig = window.weatherConfig;
            let apiUrl = jsonObjectOfWeatherConfig.apiUrl;

            if (!jsonObjectOfWeatherConfig.apiKey){
                return false;
            }

            let apiKey = jsonObjectOfWeatherConfig.apiKey;

            let completeUrl = apiUrl +this.city()+ '&appid=' + apiKey;

            $.ajax({
                url: completeUrl,
                contentType: 'application/json',
                global: true,
                type: 'GET',
                success: function (response) {
                    if (!response.main.temp){
                        return false;
                    }
                    self.temp(response.main.temp);

                    if (!response.name){
                        self.errorMessage('City not found.');
                        return false;
                    }

                    self.message($t(`Current temperature in %1 is %2°C`));
                    self.message(self.message().replace('%1', response.name)
                                                .replace('%2', Math.round((self.temp() - 273.15))));

                    self.handlePostWeatherRecord();
                },

                error: function(error) {
                    self.weatherRecordsHistory({});
                    self.errorMessage('City not found.');
                }
            });
        },
        handleCheckHistory(){
            let self = this;

            self.errorMessage('');

            let formatDateFrom = moment(this.dateFrom()).format("YYYY-MM-DD");
            let formatDateTo = moment(this.dateTo()).format("YYYY-MM-DD");

            let dates = this.customFormValidation(formatDateFrom, formatDateTo, self.city());

            if (!dates) {
                return false;
            }

            let restUrl = url.build('rest/V1/mageclass_weatherproject/' + self.city() + '/' + dates.datesFrom + '/' + dates.datesTo);

            $.ajax({
                url: restUrl,
                contentType: 'application/json',
                global: true,
                type: 'GET',
                success: function (response) {
                    self.weatherRecordsHistory(response);
                    if (self.weatherRecordsHistory().length === 0){
                        self.errorMessage($t(`There are no records.`));
                    }
                },
                error: function(error) {
                    self.errorMessage('Could not fetch any history records for input date or city.');
                }
            });
        },
        customFormValidation(dateFrom, dateTo, city){

            if (!city) {
                this.errorMessage('Invalid city');
                return false;
            }

            if (dateTo === 'Invalid date' && dateFrom === 'Invalid date'){
                this.errorMessage($t('You must input either one or both dates'));
                return false;
            }

            if (dateFrom === 'Invalid date'){
                dateFrom = 0;
            }

            if (dateTo === 'Invalid date'){
                dateTo = 0;
            }

            if (dateTo < dateFrom) {
                this.errorMessage('End date can\'t be before the front date');
                return false;
            }

            let dates = {
                datesFrom: dateFrom,
                datesTo: dateTo
            };

            return dates;
        }
    })
})