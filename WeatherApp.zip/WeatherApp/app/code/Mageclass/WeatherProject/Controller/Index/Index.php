<?php

declare(strict_types=1);

namespace Mageclass\WeatherProject\Controller\Index;

use Mageclass\WeatherProject\Model\Config;
use Magento\Framework\App\Action\HttpGetActionInterface;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\Controller\Result\ForwardFactory;

class Index implements HttpGetActionInterface
{
    private PageFactory $pageFactory;
    private ForwardFactory $forwardFactory;
    private Config $config;

    public function __construct(PageFactory $pageFactory, ForwardFactory $forwardFactory, Config $config)
    {
        $this->pageFactory = $pageFactory;
        $this->forwardFactory = $forwardFactory;
        $this->config = $config;
    }

    public function execute()
    {
        if ($this->config->isEnabled())
        {
            $page =  $this->pageFactory->create();

            $title = $this->config->getPageTitle();
            if (!$title) {
                $title = __('Weather Project');
            }
            $page->getConfig()->getTitle()->set($title);

            return $page;
        }
            $resultForward = $this->forwardFactory->create();

            $resultForward->setController('index');

            $resultForward->forward('defaultNoRoute');

            return $resultForward;
    }
}