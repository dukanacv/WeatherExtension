<?php

declare(strict_types=1);

namespace Mageclass\WeatherProject\Block;

use Mageclass\WeatherProject\Model\Config;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\View\Element\Template;

class IndexBlock extends Template
{
    private Config $config;

    public function __construct(Template\Context $context, array $data = [], Config $config)
    {
        parent::__construct($context, $data);
        $this->config = $config;
    }

    /**
     * @return mixed
     * @throws LocalizedException
     */
    public function getCustomCmsBlock()
    {
            return $this->getLayout()
                ->createBlock('Magento\Cms\Block\Block')
                ->setBlockId($this->config->getCmsBlockOption())
                ->toHtml();
    }

    /**
     * @return bool
     */
    public function isEnabled(): bool
    {
        return $this->config->isEnabled();
    }


    public function getApiConfigValues()
    {
        return $this->config->getApiConfigValues();
    }
}