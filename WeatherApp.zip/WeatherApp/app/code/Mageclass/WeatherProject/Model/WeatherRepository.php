<?php

declare(strict_types=1);

namespace Mageclass\WeatherProject\Model;

use Mageclass\WeatherProject\Api\Data\WeatherInterface;
use Mageclass\WeatherProject\Api\WeatherRepositoryInterface;

use Mageclass\WeatherProject\Model\ResourceModel\Weather\Collection;
use Mageclass\WeatherProject\Model\ResourceModel\Weather\CollectionFactory as CollectionFactory;
use Mageclass\WeatherProject\Model\ResourceModel\Weather as ResourceModel;
use Magento\Framework\Exception\AlreadyExistsException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;

class WeatherRepository implements WeatherRepositoryInterface
{
    private WeatherFactory $weatherFactory;
    private Collection $collection;
    private ResourceModel $resourceModel;
    private CollectionFactory $collectionFactory;

    public function __construct(WeatherFactory $weatherFactory, Collection $collection, ResourceModel $resourceModel, CollectionFactory $collectionFactory)
    {
        $this->weatherFactory = $weatherFactory;
        $this->collection = $collection;
        $this->resourceModel = $resourceModel;
        $this->collectionFactory = $collectionFactory;
    }

    /**
     * @throws NoSuchEntityException
     */
    public function getById($id)
    {
        $object = $this->weatherFactory->create();

        $this->resourceModel->load($object, $id);

        if(!$object->getId())
        {
            throw new NoSuchEntityException(__('Object can not be found'));
        }

        return $object;
    }

    public function getAll()
    {
        return $this->weatherFactory->create()->getCollection()->getData();
    }

    /**
     * @throws CouldNotSaveException
     */
    public function save(WeatherInterface $weather)
    {
        try{
            $this->resourceModel->save($weather);
        } catch (AlreadyExistsException $e) {
            throw new CouldNotSaveException(__($e->getMessage()));
        }

        return $weather;
    }

    public function getHistoryByDateRange(string $city, string $dateFrom, string $dateTo)
    {
        $dateFrom = (int)$dateFrom ? $dateFrom : null;
        $dateTo = (int)$dateTo ? $dateTo : null;

        $collection = $this->collection->getHistoryByDataRange($city, $dateFrom, $dateTo);

        return $collection->getData();
    }

    /**
     * @throws CouldNotSaveException
     */
    public function saveByCityAndDate(WeatherInterface $weather)
    {
        $recordToBeSaved = $this->collection->getRecordByCityAndDate($weather);

        if (!$recordToBeSaved)
        {
            return null;
        }
        $this->save($recordToBeSaved);
    }
}