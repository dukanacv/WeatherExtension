<?php

declare(strict_types=1);

namespace Mageclass\WeatherProject\Model;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Serialize\Serializer\Json;


class Config
{
    const XML_PATH_WEATHER_CMS_BLOCK_SELECT = 'weather_project/general/cms_block_select';
    const XML_PATH_WEATHER_API_KEY = 'weather_project/general/api_key';
    const XML_PATH_WEATHER_PAGE_TITLE = 'weather_project/general/page_title';
    const XML_PATH_WEATHER_API_URL = 'weather_project/general/api_url';


    private ScopeConfigInterface $scopeConfig;
    private Json $jsonEncoder;

    public function __construct(
        ScopeConfigInterface $scopeConfig,
        Json $jsonEncoder
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->jsonEncoder = $jsonEncoder;
    }

    /**
     * @return bool
     */
    public function isEnabled(): bool
    {
        return $this->scopeConfig->isSetFlag('weather_project/general/weather_enabled');
    }

    public function getCmsBlockOption()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_WEATHER_CMS_BLOCK_SELECT);
    }


    public function getPageTitle()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_WEATHER_PAGE_TITLE);
    }

    /**
     * @return string
     */
    public function getApiKey(): string
    {
        return $this->scopeConfig->getValue(self::XML_PATH_WEATHER_API_KEY);
    }

    /**
     * @return string
     */
    public function getApiUrl(): string
    {
        return (string)$this->scopeConfig->getValue(self::XML_PATH_WEATHER_API_URL);
    }


    public function getApiConfigValues()
    {
        $values = [];

        $apiUrl = $this->getApiUrl();
        $apiKey = $this->getApiKey();

        $values["apiUrl"] = $apiUrl;
        $values["apiKey"] = $apiKey;

        return $this->jsonEncoder->serialize($values);
    }
}