<?php

declare(strict_types=1);

namespace Mageclass\WeatherProject\Model\ResourceModel\Weather;

use Mageclass\WeatherProject\Api\Data\WeatherInterface;
use Mageclass\WeatherProject\Model\ResourceModel\Weather as WeatherResource;
use Mageclass\WeatherProject\Model\Weather;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;


class Collection extends AbstractCollection
{
    protected function _construct()
    {
        $this->_init(Weather::class, WeatherResource::class);
    }

    public function getHistoryByDataRange(string $city, $dateFrom, $dateTo)
    {
        $this->addFieldToFilter('city', $city);
        if ($dateFrom) {
            $this->addFieldToFilter('date', ['gt' => $dateFrom]);
        }
        if ($dateTo) {
            $this->addFieldToFilter('date', ['lt' => $dateTo]);
        }

        return $this;
    }

    public function getRecordByCityAndDate(WeatherInterface $weather)
    {
        $weatherDate = date("Y-m-d", strtotime($weather->getDate()));

        $weatherCity = $weather->getCity();

        $this->addFieldToFilter('city', $weatherCity);

        $this->addFieldToFilter('date', ['eq' => $weatherDate]);

        $recordFromDb = $this->getFirstItem();

        if ($recordFromDb && $recordFromDb->getId()){
            if ($recordFromDb->getTemp() != $weather->getTemp()) {
                $recordFromDb->setTemp($weather->getTemp());
                return $recordFromDb;
            }
        }else {
            return $weather;
        }
    }
}