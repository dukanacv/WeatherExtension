<?php

declare(strict_types=1);

namespace Mageclass\WeatherProject\Model\ResourceModel;

use Mageclass\WeatherProject\Api\Data\WeatherInterface;
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;


class Weather extends AbstractDb
{
    const TABLE_NAME = 'weather_records';


    protected function _construct()
    {
        $this->_init(self::TABLE_NAME, WeatherInterface::ID);
    }
}