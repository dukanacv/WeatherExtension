<?php
declare(strict_types=1);

namespace Mageclass\WeatherProject\Model;

use Mageclass\WeatherProject\Api\Data\WeatherInterface;
use Magento\Framework\Model\AbstractModel;

class Weather extends AbstractModel implements WeatherInterface
{
    protected function _construct()
    {
        parent::_construct();
        $this->_init(\Mageclass\WeatherProject\Model\ResourceModel\Weather::class);
    }

    /**
     * @return string
     */
    public function getCity(): string
    {
        return $this->getData(self::CITY);
    }

    /**
     * @param $name
     * @return $this
     */
    public function setCity($city): Weather
    {
        return $this->setData(self::CITY, $city);
    }


    /**
     * @return string
     */
    public function getTemp(): string
    {
        return $this->getData(self::TEMP);
    }

    /**
     * @param $temp
     * @return Weather
     */
    public function setTemp($temp): Weather
    {
        return $this->setData(self::TEMP, $temp);
    }

    /**
     * @return string
     */
    public function getDate(): string
    {
        return $this->getData(self::DATE);
    }

    /**
     * @param $date
     * @return Weather
     */
    public function setDate($date): Weather
    {
        return $this->setData(self::DATE, $date);
    }

}