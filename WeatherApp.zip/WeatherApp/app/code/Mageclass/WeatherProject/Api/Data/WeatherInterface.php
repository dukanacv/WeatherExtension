<?php

declare(strict_types=1);

namespace Mageclass\WeatherProject\Api\Data;

interface WeatherInterface
{
    const ID = 'id';
    const CITY = 'city';
    const TEMP = 'temp';
    const DATE = 'date';

    /**
     * @return int
     */
    public function getId();

    /**
     * @param int $id
     * @return $this
     */
    public function setId($id);

    /**
     * @return string
     */
    public function getCity();

    /**
     * @param $city
     * @return $this
     */
    public function setCity($city);

    /**
     * @return string
     */
    public function getTemp();

    /**
     * @param $temp
     * @return $this
     */
    public function setTemp($temp);


    /**
     * @return string
     */
    public function getDate();

    /**
     * @param $createdAt
     * @return $this
     */
    public function setDate($date);

}