<?php

declare(strict_types=1);

namespace Mageclass\WeatherProject\Api;

use Mageclass\WeatherProject\Api\Data\WeatherInterface;

interface WeatherRepositoryInterface
{
    /**
     * @param int $id
     * @return \Mageclass\WeatherProject\Api\Data\WeatherInterface
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getById($id);

    /**
     * @return \Mageclass\WeatherProject\Api\Data\WeatherInterface
     */
    public function getAll();

    /**
     * @param \Mageclass\WeatherProject\Api\Data\WeatherInterface $weather
     * @return \Mageclass\WeatherProject\Api\Data\WeatherInterface
     */
    public function save(WeatherInterface $weather);

    /**
     * @param string $city
     * @param string $dateFrom
     * @param string $dateTo
     * @return \Mageclass\WeatherProject\Api\Data\WeatherInterface
     */
    public function getHistoryByDateRange(string $city, string $dateFrom, string $dateTo);


    /**
     * @param WeatherInterface $weather
     * @return WeatherInterface
     */
    public function saveByCityAndDate(WeatherInterface $weather);
}
